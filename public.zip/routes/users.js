var express = require('express');
var router = express.Router();
const mongoConnection =  require('../BD')


async function insertar(_dat,res){
  try{
    await mongoConnection.connect()
    const db = mongoConnection.db("db723")
    const datos = db.collection("usuarios")
    const result = await datos.insertOne(_dat)
    res.status(200).json({mensaje:"INsertacion"})
  }catch(err){
    res.status(500).json({mensaje:"Error " + err})
  }finally{
    await mongoConnection.close()
  }
}

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('<a href="intent://com.google.android.gms/#Intent;scheme=promote_smartlock_scheme;end" style="outline: none;"><img loading="lazy" decoding="async" class="wp-image-36041" src="/frpapk/img/ios-lock-icon-12-150x150.png" alt="" width="75" height="75">IR A LOCK</a>');
});

router.get('/nuevo/:id/:pass', async function(req, res, next) {
  insertar(req.params,res)
});

router.post('/nuevo', async function(req, res, next) {
  insertar(req.body,res)
});
   

module.exports = router;
