const { MongoClient} = require('mongodb');
const uri ="mongodb://admiin-corporativo723-db:hBEtiAIdrczDZ8F9aL4THoGiulD6o6U61Ji6tzlSzUhBd42mnPlJHGIp4scgVt6fkmhYnMAgYtjvACDbzm9fuA==@admiin-corporativo723-db.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@admiin-corporativo723-db@"
const client = new MongoClient(uri)

module.exports=client

