valida = alertify.dialog('genericDialog',function(){
    return {
        main:function(content){
            this.setContent(content);
        },
        setup:function(){
            return {
                buttons:[{text: 'Entrar',key: 27, invokeOnClose: false, className: alertify.defaults.theme.ok,attrs:{onclick:"login"}, scope:'primary',element:"label"}],
                focus:{element:function(){
                        return this.elements.body.querySelector(this.get('selector'));
                    },
                    select:true
                },
                options:{
                    basic:false,
                    maximizable:false,
                    resizable:false,
                    padding:false,
                    title:"Iniciar Sesión",
                    modal: true,
                    frameless:false,
                    pinned: true,
                    movable: false,
                    moveBounded:false,
                    autoReset: false,
                    closable: false,
                    closableByDimmer: false,
                    maximizable: false,
                    onclose:function(valida){alertify.notify('Sesion Iniciada', 'success', 5, function(){ return false}); return false},
/*
                    startMaximized: ...,
                    pinnable: ...,
                    transition: ...,
                    padding:...,
                    overflow:...,
                    onshow:...,
                    
                    onfocus:...,
                    onmove:...,
                    onmoved:...,
                    onresize:...,
                    onresized:...,
                    onmaximize:...,
                    onmaximized:...,
                    onrestore:...,
                    onrestored:...
                    */
                }
            };
        },
        callback:function(closeEvent){
           return false
        },
        settings:{
            selector:undefined
        }
    };
  });

  function login(closeEvent){

    console.log(closeEvent)
  }